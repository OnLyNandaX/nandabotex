<a href="https://instagram.com/E_rama11"><img src="https://images.cooltext.com/5537105.png" width="320" height="211" alt="  RAM-UBOT" /></a>

<p align="center">
  <a href="https://github.com/ramadhani892/RAM-UBOT/fork">
    <img src="https://img.shields.io/github/forks/ramadhani892/RAM-UBOT?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/ramadhani892/RAM-UBOT">
    <img src="https://img.shields.io/github/stars/ramadhani892/RAM-UBOT?style=social">
  </a>
</p>  

![VIEWS](https://komarev.com/ghpvc/?username=ramadhani892)

<a href="https://t.me/ramubotspam"><img src="https://img.shields.io/badge/KODE%20PENILAIAN-A+-blue.svg?style=for-the-badge&logo=Factor.">

## DEPLOY TO HEROKU ⚠️
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/ramadhani892/Deploy-RamTod"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-indigo?style=flat&logo=heroku" width="300" height="38.60" /></a></p>



## Credit
TERIMAKASIH UNTUK

*   [VICKY](https://t.me/vckyouubitch) - ⚡Geez-Userbot⚡
*   [KOALA](https://t.me/manusiarakitann) - KAMPANG BOT
*   [TEAMULTROID](https://github.com/TeamUltroid) - ULTROID
*    DAN MASIH BANYAK LAGI TOT
